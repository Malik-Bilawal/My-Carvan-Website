$(document).ready(function () {

    $('.btn').click(function (e) {
      e.preventDefault();

      var description = $(this).data('description');


      $('#productDescription').text(description);


      $('#productModal').modal('show');
    });
  })

  // ready

  $(document).ready(function () {
  AOS.init({
    duration: 1200,  
    once: true,      
  });
});
  // br

  $(document).ready(function () {
  $('.btn').click(function (e) {
    e.preventDefault();
    var description = $(this).data('description');
    
    $('#productDescription').html(description);

    
    $('#productModal').modal('show').fadeIn(600);
  });
});